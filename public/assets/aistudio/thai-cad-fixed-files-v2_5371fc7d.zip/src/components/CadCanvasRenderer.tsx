/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Maximize2, ZoomIn, ZoomOut, Layers, Eye } from 'lucide-react';
import { CadEntity, ParsedCadModel, Point2D, ThaiFontFamily, ThemeMode, CadSpaceFilter } from '../types/cad';
import { getContrastedCadColor } from '../utils/cadColors';

interface CadCanvasRendererProps {
  model: ParsedCadModel;
  theme: ThemeMode;
  fontFamily: ThaiFontFamily;
  selectedEntity: CadEntity | null;
  onSelectEntity: (entity: CadEntity | null) => void;
  isMeasureMode: boolean;
  onFinishMeasurement?: (dist: number, p1: Point2D, p2: Point2D) => void;
  showGrid: boolean;
  textScaleMultiplier: number;
}

export const CadCanvasRenderer: React.FC<CadCanvasRendererProps> = ({
  model,
  theme,
  fontFamily,
  selectedEntity,
  onSelectEntity,
  isMeasureMode,
  onFinishMeasurement,
  showGrid,
  textScaleMultiplier,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // View state: pan in pixels and zoom (pixels per CAD unit)
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // CAD Space filter: Model Space vs Paper Space
  const [spaceFilter, setSpaceFilter] = useState<CadSpaceFilter>('all');

  // Measurement tool state
  const [measurePoint1, setMeasurePoint1] = useState<Point2D | null>(null);
  const [measureCurrentPoint, setMeasureCurrentPoint] = useState<Point2D | null>(null);

  // Mouse CAD coordinates for status bar
  const [mouseCadCoord, setMouseCadCoord] = useState<Point2D>({ x: 0, y: 0 });

  // Fit drawing to view (supports contentBounds vs fullBounds)
  const fitToView = useCallback(
    (useFull = false) => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const b = (useFull && model.fullBounds) ? model.fullBounds : (model.contentBounds || model.bounds);
      if (!b) return;

      const rect = canvas.getBoundingClientRect();
      const margin = 48; // padding in pixels
      const availW = Math.max(rect.width - margin * 2, 50);
      const availH = Math.max(rect.height - margin * 2, 50);

      const width = Math.max(b.width, 0.0001);
      const height = Math.max(b.height, 0.0001);
      const scaleX = availW / width;
      const scaleY = availH / height;
      let newZoom = Math.min(scaleX, scaleY);

      if (!isFinite(newZoom) || newZoom <= 0) {
        newZoom = 1;
      }

      const centerX = isFinite(b.centerX) ? b.centerX : 0;
      const centerY = isFinite(b.centerY) ? b.centerY : 0;

      const newPan = {
        x: rect.width / 2 - centerX * newZoom,
        y: rect.height / 2 + centerY * newZoom,
      };

      setZoom(newZoom);
      setPan(newPan);
    },
    [model]
  );

  const handleZoomIn = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const cadUnderCenter = screenToCad(centerX, centerY);
    const newZoom = Math.min(zoom * 1.35, 10000000);
    setPan({
      x: centerX - cadUnderCenter.x * newZoom,
      y: centerY + cadUnderCenter.y * newZoom,
    });
    setZoom(newZoom);
  };

  const handleZoomOut = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const cadUnderCenter = screenToCad(centerX, centerY);
    const newZoom = Math.max(zoom * 0.74, 0.0000001);
    setPan({
      x: centerX - cadUnderCenter.x * newZoom,
      y: centerY + cadUnderCenter.y * newZoom,
    });
    setZoom(newZoom);
  };

  // Initial fit on model change
  useEffect(() => {
    fitToView(false);
  }, [model, fitToView]);


  // Coordinate conversion helpers
  const cadToScreen = useCallback(
    (cadX: number, cadY: number) => {
      return {
        x: pan.x + cadX * zoom,
        y: pan.y - cadY * zoom,
      };
    },
    [pan, zoom]
  );

  const screenToCad = useCallback(
    (screenX: number, screenY: number) => {
      return {
        x: (screenX - pan.x) / zoom,
        y: (pan.y - screenY) / zoom,
      };
    },
    [pan, zoom]
  );

  // Wheel zoom handler
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.87;
    const newZoom = Math.max(Math.min(zoom * zoomFactor, 10000000), 0.0000001);

    // Zoom centered at mouse position
    const cadUnderMouse = screenToCad(mouseX, mouseY);
    const newPan = {
      x: mouseX - cadUnderMouse.x * newZoom,
      y: mouseY + cadUnderMouse.y * newZoom,
    };

    setZoom(newZoom);
    setPan(newPan);
  };

  // Mouse down: drag or start measurement
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const cadPt = screenToCad(mouseX, mouseY);

    // If middle click or space key pressed or normal left click when not measuring
    if (e.button === 1 || (!isMeasureMode && e.button === 0)) {
      setIsDragging(true);
      setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }

    if (isMeasureMode && e.button === 0) {
      if (!measurePoint1) {
        setMeasurePoint1(cadPt);
        setMeasureCurrentPoint(cadPt);
      } else {
        // Complete measurement
        const dx = cadPt.x - measurePoint1.x;
        const dy = cadPt.y - measurePoint1.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (onFinishMeasurement) {
          onFinishMeasurement(dist, measurePoint1, cadPt);
        }
        setMeasurePoint1(null);
        setMeasureCurrentPoint(null);
      }
    }
  };

  // Mouse move: panning or hovering / updating coordinates
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const cadPt = screenToCad(mouseX, mouseY);

    setMouseCadCoord(cadPt);

    if (isDragging) {
      setPan({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    }

    if (isMeasureMode && measurePoint1) {
      setMeasureCurrentPoint(cadPt);
    }
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) {
      setIsDragging(false);
      // If minimal drag distance, treat as click to select entity
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;
      const dragDist = Math.hypot(e.clientX - dragStart.x - pan.x, e.clientY - dragStart.y - pan.y);

      if (dragDist < 5 && !isMeasureMode) {
        handleEntityClick(mouseX, mouseY);
      }
    }
  };

  // Click detection: find nearest entity within 15px radius
  const handleEntityClick = (screenX: number, screenY: number) => {
    let nearest: CadEntity | null = null;
    let minDistance = 15; // pixel threshold

    for (const ent of model.entities) {
      const layer = model.layers[ent.layer];
      if (layer && !layer.visible) continue;

      if (ent.type === 'LINE') {
        const s = cadToScreen(ent.start.x, ent.start.y);
        const e = cadToScreen(ent.end.x, ent.end.y);
        const d = distToSegment({ x: screenX, y: screenY }, s, e);
        if (d < minDistance) {
          minDistance = d;
          nearest = ent;
        }
      } else if (ent.type === 'TEXT' || ent.type === 'MTEXT') {
        const p = cadToScreen(ent.position.x, ent.position.y);
        const d = Math.hypot(p.x - screenX, p.y - screenY);
        if (d < minDistance + 10) {
          minDistance = d;
          nearest = ent;
        }
      } else if (ent.type === 'CIRCLE') {
        const c = cadToScreen(ent.center.x, ent.center.y);
        const rScreen = ent.radius * zoom;
        const dCenter = Math.hypot(c.x - screenX, c.y - screenY);
        const dRim = Math.abs(dCenter - rScreen);
        if (dRim < minDistance) {
          minDistance = dRim;
          nearest = ent;
        }
      }
    }

    onSelectEntity(nearest);
  };

  function distToSegment(p: Point2D, v: Point2D, w: Point2D): number {
    const l2 = (v.x - w.x) ** 2 + (v.y - w.y) ** 2;
    if (l2 === 0) return Math.hypot(p.x - v.x, p.y - v.y);
    let t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
    t = Math.max(0, Math.min(1, t));
    return Math.hypot(p.x - (v.x + t * (w.x - v.x)), p.y - (v.y + t * (w.y - v.y)));
  }

  // Primary Canvas Draw loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    if (canvas.width !== rect.width * dpr || canvas.height !== rect.height * dpr) {
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
    }

    ctx.save();
    ctx.scale(dpr, dpr);

    // Clear background based on theme
    let bgColor = '#0f141c';
    let defaultStroke = '#f8fafc';
    let gridMajorColor = 'rgba(255, 255, 255, 0.08)';
    let gridMinorColor = 'rgba(255, 255, 255, 0.03)';

    if (theme === 'blueprint') {
      bgColor = '#0a2342';
      defaultStroke = '#e0f2fe';
      gridMajorColor = 'rgba(56, 189, 248, 0.18)';
      gridMinorColor = 'rgba(56, 189, 248, 0.08)';
    } else if (theme === 'light') {
      bgColor = '#ffffff';
      defaultStroke = '#0f172a';
      gridMajorColor = 'rgba(0, 0, 0, 0.08)';
      gridMinorColor = 'rgba(0, 0, 0, 0.03)';
    }

    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, rect.width, rect.height);

    // Draw grid if enabled
    if (showGrid) {
      // Find appropriate grid step based on zoom
      const rawStep = 50 / zoom;
      const mag = Math.pow(10, Math.floor(Math.log10(rawStep)));
      let step = mag;
      if (rawStep / mag > 5) step = mag * 5;
      else if (rawStep / mag > 2) step = mag * 2;

      const minCad = screenToCad(0, rect.height);
      const maxCad = screenToCad(rect.width, 0);

      const startX = Math.floor(minCad.x / step) * step;
      const endX = Math.ceil(maxCad.x / step) * step;
      const startY = Math.floor(minCad.y / step) * step;
      const endY = Math.ceil(maxCad.y / step) * step;

      ctx.lineWidth = 1;
      ctx.strokeStyle = gridMinorColor;
      ctx.beginPath();
      for (let gx = startX; gx <= endX; gx += step) {
        const s = cadToScreen(gx, 0);
        ctx.moveTo(s.x, 0);
        ctx.lineTo(s.x, rect.height);
      }
      for (let gy = startY; gy <= endY; gy += step) {
        const s = cadToScreen(0, gy);
        ctx.moveTo(0, s.y);
        ctx.lineTo(rect.width, s.y);
      }
      ctx.stroke();

      // Major axes (0,0)
      const origin = cadToScreen(0, 0);
      ctx.strokeStyle = gridMajorColor;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(origin.x, 0);
      ctx.lineTo(origin.x, rect.height);
      ctx.moveTo(0, origin.y);
      ctx.lineTo(rect.width, origin.y);
      ctx.stroke();
    }

    // Draw CAD Entities
    for (const ent of model.entities) {
      // Space filter (Model Space vs Paper Space)
      if (spaceFilter === 'model' && ent.paperSpace) continue;
      if (spaceFilter === 'paper' && !ent.paperSpace) continue;

      const layer = model.layers[ent.layer];
      if (layer && !layer.visible) continue;

      const isSelected = selectedEntity?.id === ent.id;

      // Color selection with contrast booster (no invisible black lines on dark background)
      const rawColor = ent.color || layer?.color || defaultStroke;
      const strokeColor = getContrastedCadColor(rawColor, theme, defaultStroke);

      ctx.strokeStyle = isSelected ? '#f59e0b' : strokeColor;
      // ความกว้างเส้น: ใช้ความกว้าง polyline จริง (หน่วย CAD × zoom) แต่ไม่บางกว่า 1.25px
      const baseLw = ent.lineWidth && ent.lineWidth > 0 ? Math.max(ent.lineWidth * zoom, 1.25) : 1.25;
      ctx.lineWidth = isSelected ? Math.max(3, baseLw) : Math.min(baseLw, 40);
      // เส้นประ/จุด: ถ้า pattern เล็กกว่า ~4px ต่อคาบ ให้วาดทึบเพื่อไม่ให้ดูเหมือนเส้นหาย
      if (ent.dash && ent.dash.length > 0) {
        const px = ent.dash.map((d) => Math.max(Math.abs(d) * zoom, d === 0 ? 1 : 0.5));
        const period = px.reduce((a, b) => a + b, 0);
        ctx.setLineDash(period >= 4 ? (px.length % 2 ? [...px, ...px] : px) : []);
      } else {
        ctx.setLineDash([]);
      }

      switch (ent.type) {
        case 'LINE': {
          const s = cadToScreen(ent.start.x, ent.start.y);
          const e = cadToScreen(ent.end.x, ent.end.y);
          ctx.beginPath();
          ctx.moveTo(s.x, s.y);
          ctx.lineTo(e.x, e.y);
          ctx.stroke();
          break;
        }

        case 'LWPOLYLINE':
        case 'POLYLINE': {
          if (!ent.vertices || ent.vertices.length < 2) break;
          ctx.beginPath();
          const first = cadToScreen(ent.vertices[0].x, ent.vertices[0].y);
          ctx.moveTo(first.x, first.y);
          for (let i = 1; i < ent.vertices.length; i++) {
            const pt = cadToScreen(ent.vertices[i].x, ent.vertices[i].y);
            ctx.lineTo(pt.x, pt.y);
          }
          if (ent.closed) {
            ctx.closePath();
          }
          ctx.stroke();
          break;
        }

        case 'CIRCLE': {
          const c = cadToScreen(ent.center.x, ent.center.y);
          const r = ent.radius * zoom;
          ctx.beginPath();
          ctx.arc(c.x, c.y, Math.max(r, 0.5), 0, Math.PI * 2);
          ctx.stroke();
          break;
        }

        case 'ARC': {
          const c = cadToScreen(ent.center.x, ent.center.y);
          const r = ent.radius * zoom;
          const sa = -ent.startAngle;
          const ea = -ent.endAngle;
          ctx.beginPath();
          ctx.arc(c.x, c.y, Math.max(r, 0.5), sa, ea, true);
          ctx.stroke();
          break;
        }

        case 'ELLIPSE': {
          const c = cadToScreen(ent.center.x, ent.center.y);
          const rX = ent.majorRadius * zoom;
          const rY = ent.minorRadius * zoom;
          ctx.save();
          ctx.translate(c.x, c.y);
          if (ent.rotation) {
            ctx.rotate(-ent.rotation);
          }
          ctx.beginPath();
          ctx.ellipse(0, 0, Math.max(rX, 0.5), Math.max(rY, 0.5), 0, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
          break;
        }

        case 'SPLINE':
        case 'LEADER': {
          const pts = ent.type === 'SPLINE' ? ent.points : ent.vertices;
          if (!pts || pts.length < 2) break;
          ctx.beginPath();
          const first = cadToScreen(pts[0].x, pts[0].y);
          ctx.moveTo(first.x, first.y);
          for (let pi = 1; pi < pts.length; pi++) {
            const pt = cadToScreen(pts[pi].x, pts[pi].y);
            ctx.lineTo(pt.x, pt.y);
          }
          if (ent.type === 'SPLINE' && ent.closed) {
            ctx.closePath();
          }
          ctx.stroke();
          break;
        }

        case 'HATCH': {
          if (!ent.loops || ent.loops.length === 0) break;
          ctx.beginPath();
          for (const lp of ent.loops) {
            if (lp.length < 3) continue;
            const f = cadToScreen(lp[0].x, lp[0].y);
            ctx.moveTo(f.x, f.y);
            for (let pi = 1; pi < lp.length; pi++) {
              const pt = cadToScreen(lp[pi].x, lp[pi].y);
              ctx.lineTo(pt.x, pt.y);
            }
            ctx.closePath();
          }
          ctx.save();
          ctx.fillStyle = strokeColor;
          ctx.globalAlpha = ent.solid ? 1 : 0.3;
          ctx.fill('evenodd');
          ctx.restore();
          break;
        }

        case 'SOLID': {
          if (!ent.points || ent.points.length < 3) break;
          ctx.beginPath();
          const first = cadToScreen(ent.points[0].x, ent.points[0].y);
          ctx.moveTo(first.x, first.y);
          for (let pi = 1; pi < ent.points.length; pi++) {
            const pt = cadToScreen(ent.points[pi].x, ent.points[pi].y);
            ctx.lineTo(pt.x, pt.y);
          }
          ctx.closePath();
          ctx.save();
          ctx.fillStyle = strokeColor;
          ctx.globalAlpha = 0.35;
          ctx.fill();
          ctx.restore();
          ctx.stroke();
          break;
        }

        case 'TEXT': {
          const p = cadToScreen(ent.position.x, ent.position.y);
          const fontHeight = ent.height * zoom * textScaleMultiplier;
          // ข้อความที่เล็กกว่า ~3px อ่านไม่ออกอยู่แล้ว — ข้ามไปเลย แทนที่จะบังคับขั้นต่ำ 10px จนทับกันเต็มจอ
          if (fontHeight < 3 && !isSelected) break;
          ctx.save();
          ctx.font = `${Math.round(fontHeight)}px "${fontFamily}", "Sarabun", sans-serif`;
          ctx.fillStyle = isSelected ? '#f59e0b' : strokeColor;
          ctx.textBaseline = 'alphabetic';

          ctx.translate(p.x, p.y);
          if (ent.rotation) {
            ctx.rotate((-ent.rotation * Math.PI) / 180);
          }
          ctx.fillText(ent.decodedText, 0, 0);
          ctx.restore();
          break;
        }

        case 'MTEXT': {
          const p = cadToScreen(ent.position.x, ent.position.y);
          const fontHeight = ent.height * zoom * textScaleMultiplier;
          if (fontHeight < 3 && !isSelected) break;
          const lineSpacing = fontHeight * 1.35;
          ctx.save();
          ctx.font = `${Math.round(fontHeight)}px "${fontFamily}", "Sarabun", sans-serif`;
          ctx.fillStyle = isSelected ? '#f59e0b' : strokeColor;
          ctx.textBaseline = 'top';

          ctx.translate(p.x, p.y);
          if (ent.rotation) {
            ctx.rotate((-ent.rotation * Math.PI) / 180);
          }

          const lines = ent.lines || [ent.decodedText];
          for (let lIdx = 0; lIdx < lines.length; lIdx++) {
            ctx.fillText(lines[lIdx], 0, lIdx * lineSpacing);
          }
          ctx.restore();
          break;
        }

        case 'DIMENSION': {
          if (ent.middlePoint) {
            const p = cadToScreen(ent.middlePoint.x, ent.middlePoint.y);
            const fontHeight = Math.max(11, 2.5 * zoom * textScaleMultiplier);
            ctx.save();
            ctx.font = `${Math.round(fontHeight)}px "${fontFamily}", "Sarabun", sans-serif`;
            ctx.fillStyle = isSelected ? '#f59e0b' : strokeColor;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            if (ent.decodedText) {
              ctx.fillText(ent.decodedText, p.x, p.y);
            }
            if (ent.definitionPoint) {
              const defP = cadToScreen(ent.definitionPoint.x, ent.definitionPoint.y);
              ctx.beginPath();
              ctx.strokeStyle = strokeColor;
              ctx.setLineDash([3, 3]);
              ctx.moveTo(p.x, p.y);
              ctx.lineTo(defP.x, defP.y);
              ctx.stroke();
              ctx.setLineDash([]);
            }
            ctx.restore();
          }
          break;
        }

        default:
          break;
      }
    }

    // Draw active measurement line if in measure mode
    if (isMeasureMode && measurePoint1 && measureCurrentPoint) {
      const p1 = cadToScreen(measurePoint1.x, measurePoint1.y);
      const p2 = cadToScreen(measureCurrentPoint.x, measureCurrentPoint.y);
      const dx = measureCurrentPoint.x - measurePoint1.x;
      const dy = measureCurrentPoint.y - measurePoint1.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      ctx.save();
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 4]);

      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();

      // End points
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(p1.x, p1.y, 4, 0, Math.PI * 2);
      ctx.arc(p2.x, p2.y, 4, 0, Math.PI * 2);
      ctx.fill();

      // Measurement pill tag
      const midX = (p1.x + p2.x) / 2;
      const midY = (p1.y + p2.y) / 2;
      const distText = `ระยะ ${dist.toFixed(3)} ม. (ΔX: ${dx.toFixed(2)}, ΔY: ${dy.toFixed(2)})`;

      ctx.font = `12px "${fontFamily}", "Sarabun", sans-serif`;
      const textMetrics = ctx.measureText(distText);
      const textW = textMetrics.width;

      ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.fillRect(midX - textW / 2 - 8, midY - 20, textW + 16, 24);
      ctx.strokeStyle = '#f59e0b';
      ctx.setLineDash([]);
      ctx.strokeRect(midX - textW / 2 - 8, midY - 20, textW + 16, 24);

      ctx.fillStyle = '#fef08a';
      ctx.textBaseline = 'middle';
      ctx.textAlign = 'center';
      ctx.fillText(distText, midX, midY - 8);
      ctx.restore();
    }

    ctx.restore();
  }, [
    model,
    zoom,
    pan,
    theme,
    fontFamily,
    selectedEntity,
    showGrid,
    textScaleMultiplier,
    isMeasureMode,
    measurePoint1,
    measureCurrentPoint,
    cadToScreen,
    screenToCad,
  ]);

  return (
    <div className="relative w-full h-full select-none overflow-hidden cursor-crosshair">
      <canvas
        ref={canvasRef}
        className="w-full h-full block"
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
      />

      {/* Real-time CAD status indicators */}
      <div className="absolute bottom-3 left-4 flex items-center gap-3 text-xs text-neutral-400 bg-neutral-900/85 backdrop-blur-sm border border-neutral-800 px-3 py-1.5 rounded pointer-events-none tabular-nums font-mono">
        <span>
          X: <strong className="text-neutral-200">{mouseCadCoord.x.toFixed(3)}</strong>
        </span>
        <span className="text-neutral-600">|</span>
        <span>
          Y: <strong className="text-neutral-200">{mouseCadCoord.y.toFixed(3)}</strong>
        </span>
        <span className="text-neutral-600">|</span>
        <span>
          Zoom: <strong className="text-neutral-200">{Math.round(zoom * 100)}%</strong>
        </span>
        <span className="text-neutral-600">|</span>
        <span className="text-emerald-400 font-sans">Canvas 2D (HarfBuzz Thai)</span>
      </div>

      {/* Viewport Floating Zoom & Fit Controls */}
      <div className="absolute bottom-3 right-4 flex items-center gap-1.5 bg-neutral-900/95 backdrop-blur-md border border-neutral-800 p-1.5 rounded-lg shadow-2xl z-10 text-xs">
        {/* Space filter (if PaperSpace exists) */}
        {(model.paperSpaceCount || 0) > 0 && (
          <div className="flex items-center bg-neutral-950 p-0.5 rounded border border-neutral-800 mr-1">
            <button
              onClick={() => setSpaceFilter('all')}
              className={`px-2 py-0.5 text-[11px] rounded transition-colors cursor-pointer ${
                spaceFilter === 'all'
                  ? 'bg-neutral-800 text-amber-300 font-medium'
                  : 'text-neutral-400 hover:text-white'
              }`}
              title="แสดงทั้ง Model Space และ Paper Space"
            >
              ทั้งหมด
            </button>
            <button
              onClick={() => setSpaceFilter('model')}
              className={`px-2 py-0.5 text-[11px] rounded transition-colors cursor-pointer ${
                spaceFilter === 'model'
                  ? 'bg-amber-400/20 text-amber-300 font-medium border border-amber-500/30'
                  : 'text-neutral-400 hover:text-white'
              }`}
              title="แสดงเฉพาะพื้นที่โมเดล (Model Space - ตัวผังและโครงสร้างจริง)"
            >
              โมเดล ({model.modelSpaceCount || 0})
            </button>
            <button
              onClick={() => setSpaceFilter('paper')}
              className={`px-2 py-0.5 text-[11px] rounded transition-colors cursor-pointer ${
                spaceFilter === 'paper'
                  ? 'bg-sky-400/20 text-sky-300 font-medium border border-sky-500/30'
                  : 'text-neutral-400 hover:text-white'
              }`}
              title="แสดงเฉพาะพื้นที่กระดาษ (Layout / Title Block)"
            >
              กระดาษ ({model.paperSpaceCount || 0})
            </button>
          </div>
        )}

        <button
          onClick={handleZoomIn}
          className="p-1.5 text-neutral-300 hover:text-white hover:bg-neutral-800 rounded transition-colors cursor-pointer"
          title="ซูมเข้า (Zoom In) หรือใช้ลูกกลิ้งเมาส์"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={handleZoomOut}
          className="p-1.5 text-neutral-300 hover:text-white hover:bg-neutral-800 rounded transition-colors cursor-pointer"
          title="ซูมออก (Zoom Out) หรือใช้ลูกกลิ้งเมาส์"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <div className="w-[1px] h-4 bg-neutral-800 mx-0.5" />
        <button
          onClick={() => fitToView(false)}
          className="px-2.5 py-1 text-xs text-amber-400 hover:text-amber-300 hover:bg-neutral-800 rounded transition-colors flex items-center gap-1 font-medium cursor-pointer"
          title="ซูมพอดีผังหลัก (Fit to Plan - ตัดพิกัดหลุดขอบ 0,0)"
        >
          <Maximize2 className="w-3.5 h-3.5" />
          <span>พอดีผัง</span>
        </button>
        {model.fullBounds && (model.fullBounds.width > model.bounds.width * 1.5 || model.fullBounds.height > model.bounds.height * 1.5) && (
          <button
            onClick={() => fitToView(true)}
            className="px-2 py-1 text-xs text-neutral-400 hover:text-white hover:bg-neutral-800 rounded transition-colors flex items-center gap-1 cursor-pointer"
            title="ซูมรวมขอบเขตทั้งหมดรวมกรอบและพิกัดอ้างอิง (Fit All Extents)"
          >
            <span>ขอบเขตรวม</span>
          </button>
        )}
      </div>


      {isMeasureMode && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-amber-500/90 text-neutral-950 font-medium text-xs px-4 py-1.5 rounded shadow-lg flex items-center gap-2 pointer-events-none">
          <span>
            {measurePoint1
              ? 'คลิกจุดที่ 2 เพื่อระบุระยะทาง'
              : 'คลิกจุดที่ 1 เพื่อเริ่มวัดระยะ (CAD Units / ม.)'}
          </span>
        </div>
      )}
    </div>
  );
};
